# Karnataka Rice Yield Research — Code and Data Package

This package contains saved notebooks, datasets and selected irrigation subgroup result tables recovered from the project files.

## Folder structure
- `notebooks/`: Colab notebooks
- `data/`: available rice-yield, merged climate/irrigation, preprocessed panel, centroid and observed-irrigation datasets
- `results/`: saved irrigation subgroup metrics

## Important data provenance and limitations
- Rice APY source: ICAR-IIRR Rice APY Dashboard (Area, Production & Yield Analytics), as documented in the project methodology.
- Climate sources documented in the project: CHIRPS rainfall and NASA POWER temperature.
- Irrigation observations were extracted from Karnataka Department of Economics and Statistics district crop reports. Some early scanned-report values were OCR-derived and should be treated with the confidence limitations documented in the research notes.
- `karnataka_rice_climate_irrigation_merged_2000_2023_5YEAR_AUDITED.csv` is the available audited merged panel.
- `irrigation_observed_years_only_dataset.csv` is the subset with directly observed irrigation records; it is not the full panel.

## Files not included
The original standalone raw CHIRPS rainfall export and raw NASA POWER temperature export were not present among the saved project files available for this package. They are therefore not fabricated or substituted. If the notebook requires them for an earlier extraction/merge step, add the original source exports separately after retrieving them from the original Colab/Drive workspace.

## Before reproducing
1. Open the notebook and check its `read_csv()` filenames.
2. Update paths to point to the files in `data/` (or upload the required CSVs into Colab).
3. Confirm that the notebook's expected dataset matches the chosen panel version.
4. Run cells in order and verify the printed dataset shape and columns.
5. Do not interpret the static irrigation fallback labels as directly observed historical irrigation measurements.

## Sharing
Check source-data redistribution permissions before making the repository public. Do not upload API keys, credentials, or private information.
